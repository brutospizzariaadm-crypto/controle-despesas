# Controle de Despesas — Projeto Bimestral (PARTE 02)

**Aluno:** Anna Carolina Guilhen

## Objetivo da Parte 02
Implementar o MVP funcional (POC) do sistema de controle de despesas: cadastro de despesas com prioridade, registro de pagamentos, listagem e persistência. Tudo em Java puro, rodando pelo terminal.
