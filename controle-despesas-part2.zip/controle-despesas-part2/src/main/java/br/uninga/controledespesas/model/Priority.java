
package br.uninga.controledespesas.model;

public enum Priority {
    BAIXA, MEDIA, ALTA
}
